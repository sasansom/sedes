This zip file contains two versions of Cardo italic.  Both are OpenType fonts; one has TrueType outlines (.ttf) and the other PostScript outlines (.otf).  Characters and OpenType features (ligatures, etc.) are the same in both.  On my Windows system the OTF has a better on-screen appearance, but this may vary depending on your monitor and graphics card.

Don't install both at once!

In the future I may distribute Cardo only as .otf font files, but I am interested in hearing if people need or prefer the .ttf format.